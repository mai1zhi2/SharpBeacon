﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Beacon.Crypt.Internal
{
    public enum RsaSize
    {
        R2048 = 2048,
        R3072 = 3072,
        R4096 = 4096
    }
}
